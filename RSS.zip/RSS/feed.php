<?php


						$phpdata = mysql_connect("localhost" , "root" , "shikhu123")
						or die(mysql_error());

						mysql_select_db("phpdata" , $phpdata);
						if (isset($_POST['name']))
							$name = $_POST['name'];
						if (isset($_POST['mail']))
						{
							$mail = $_POST['mail'];
						}
						if (isset($_POST['phone']))
							$phone = $_POST['phone'];
						if (isset($_POST['message']))	
							$message = $_POST['message'];
							
						if ( $name and  $mail and $phone and $message)
						{		
							
							$sql = "insert into feedback (Fname , Email , Phone , Message) values ( '$name' , '$mail' , '$phone' , '$message')";

							$r = mysql_query($sql , $phpdata);
						
							if (!$r)
								echo mysql_error();
							else
								header("Location: contact.php?msg2=Your feedback considered successfully");
						}
						else
							header("Location: contact.php?msg1=Please fill up all the fields");
					?>