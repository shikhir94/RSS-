

<?php


$phpdata = mysql_connect("localhost" , "root" , "shikhu123")
or die(mysql_error());

mysql_select_db("phpdata" , $phpdata);

if (isset($_POST['fname']))
{
	echo $_POST['fname'];
	$fname = $_POST['fname'];
	echo ''.$fname.'';
}
if (isset($_POST['username']))
{
	$uname = $_POST['username'];
}
if (isset($_POST['pwd1']))
{
	$pwd1 = $_POST['pwd1'];
}
if (isset($_POST['pwd2']))
{
	$pwd2 = $_POST['pwd2'];
}
if (isset($_POST['Email']))
{
	$mail = $_POST['Email'];
	echo $mail;
}
if (isset($_POST['radiobutton']))
{
	$rbt = $_POST['radiobutton'];
	echo $_POST['radiobutton'];
	echo ''.$rbt.'';
}

if (isset($fname) and isset($uname) and isset($pwd1) and isset($pwd2) and isset($mail) and isset($rbt))
{
	$sql = "insert into users (Person , Uname , Password , CPassword , Email , Gender) values
								( '$fname' , '$uname' , '$pwd1' , '$pwd2' , '$mail' , '$rbt')";

	$r = mysql_query($sql , $phpdata);
	
	if (!$r)
		echo mysql_error();
	else
	{
		//echo 'insert successfull';
		header ("Location: form.php?cc=You are added successfully");
	}
}
else
	echo 'Please insert complete values';
?>


