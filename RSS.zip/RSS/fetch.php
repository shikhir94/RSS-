


<?php
$c =0;
$phpdata = mysql_connect("localhost" , "root" , "shikhu123")
or die(mysql_error());

mysql_select_db("phpdata" , $phpdata);


if (isset($_POST['uname']))
	$uname = $_POST['uname'];
if (isset($_POST['pwd1']))
	$passwd = $_POST['pwd1'];



$sql = "select * from users";

$r = mysql_query($sql);


if (	$uname  and  $passwd )
{
	
	
	while ($row = mysql_fetch_array($r))	
	{
		if ($row[3] == $passwd and $row[1] == $uname )
		{
			$c = 1;
			
		}
	}
		if ($c == 1)
			header("Location: index.html");
		else
			header("Location: form.php?msg=SORRY!!You are not registered,please sign up");
}	
else
	header("Location: form.php?msg2=Please enter the fields");

?>


